const jwt = require("jsonwebtoken");

const jwtPublicKey = `-----BEGIN RSA PUBLIC KEY-----
MIIBCgKCAQEAodD/IEagav7wlBX+k30YOSFpYT0u7AtV3ljwC52ShCFFGVvw86T5
VTbg5Q/L/dgQT0+OZi+Fe/aAIL6j+3d8+Md5nGg7zqTv33GE7tN4ZoSkYnPMAm1I
PjkOevpia98u8n1jWE/OnDnQqgozcy2zssGcJ1+QwJWuZWVObbFiA6ppFlyb9Hm8
2wEgvBqjuTqCvLdJO5CtY5ya5OpGLpnqlsXTRgJEEFk0VTdH56ztcLFMDMxm4OVW
aWy+i4YieTRRKnbyT7fzDPiZupkcg2jwVF49CtyB9UWtE/+/BAKtJtBLfdZ5X1dK
RqesE10ysVdGxeyeRpyFltEfF5QWAzn99wIDAQAB
-----END RSA PUBLIC KEY-----`;

// This handler validates the token
exports.handler = (event, context, callback) => {
  try {
    // Remove "Bearer" from the token if it is present
    const accessToken = event.authorizationToken.replace(/^Bearer /, "");

    // Verify the token
    jwt.verify(
      accessToken,
      jwtPublicKey,
      { algorithms: ["RS256"] },
      (error, decoded) => {
        if (error) {
          callback("Unauthorized");
        } else {
          callback(null, generatePolicy("user", "Allow", event.methodArn));
        }
      }
    );
  } catch (error) {
    callback(null, generatePolicy("user", "Deny", event.methodArn));
  }
};

// Helper function to generate an AWS IAM policy
var generatePolicy = function (principalId, effect, resource) {
  var authResponse = {};

  authResponse.principalId = principalId;
  if (effect && resource) {
    var policyDocument = {};
    policyDocument.Version = "2012-10-17";
    policyDocument.Statement = [];
    var statementOne = {};
    statementOne.Action = "execute-api:Invoke";
    statementOne.Effect = effect;
    statementOne.Resource = resource;
    policyDocument.Statement[0] = statementOne;
    authResponse.policyDocument = policyDocument;
  }

  return authResponse;
};
